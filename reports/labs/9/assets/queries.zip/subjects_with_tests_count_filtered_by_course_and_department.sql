select [test_subjects].*, 
(
	select count(*) 
	from [tests] 
	where [test_subjects].[id] = [tests].[test_subject_id] 
		and [tests].[deleted_at] is null
) as [tests_count] 
from [test_subjects] 
where exists (
	select * 
	from [courses] 
	inner join [course_test_subject] 
	on [courses].[id] = [course_test_subject].[course_id] 
	where [test_subjects].[id] = [course_test_subject].[test_subject_id] 
		and [id] = 4
) and exists (
	select * 
	from [departments] 
	inner join [department_test_subject] 
	on [departments].[id] = [department_test_subject].[department_id] 
	where [test_subjects].[id] = [department_test_subject].[test_subject_id] 
		and [uri_alias] = 'software-engineering' 
		and [departments].[deleted_at] is null
)