select test_composite.*
from [test_composite] 
inner join tests
on tests.id=test_composite.id_test
where tests.uri_alias = 'encapsulation' 
	and [test_composite].[id_test] is not null
