select * 
from [test_subjects] 
where exists (
	select * 
	from [tests] 
	where [test_subjects].[id] = [tests].[test_subject_id] 
		and exists (
			select * 
			from [test_results] 
			where [tests].[id] = [test_results].[test_id]
		)
	)