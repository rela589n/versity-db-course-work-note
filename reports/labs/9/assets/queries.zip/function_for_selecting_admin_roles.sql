CREATE FUNCTION admin_roles (@adminId INT) RETURNS TABLE
AS 
RETURN
	select [roles].*, 
		[model_has_roles].[model_id] as [pivot_model_id], 
		[model_has_roles].[role_id] as [pivot_role_id], 
		[model_has_roles].[model_type] as [pivot_model_type] 
	from [roles] 
	inner join [model_has_roles] 
	on [roles].[id] = [model_has_roles].[role_id] 
	where [model_has_roles].[model_id] = @adminId
		and [model_has_roles].[model_type] = 'App\Models\Administrator'