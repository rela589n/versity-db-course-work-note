select [tests].*, 
(
	select count(*) 
	from [questions] 
	where [tests].[id] = [questions].[test_id] 
		and [questions].[deleted_at] is null
) as [questions_count] 
from [tests] 
where [tests].[test_subject_id] = 2 
	and [tests].[deleted_at] is null 
order by [name] asc