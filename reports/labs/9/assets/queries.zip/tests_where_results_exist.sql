select * 
from [tests] 
where [tests].[test_subject_id] is not null 
	and exists (
		select [id]
		from [test_results] 
		where [tests].[id] = [test_results].[test_id]
	) 
order by [name] asc