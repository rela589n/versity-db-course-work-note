select * from (
	select top 5 [questions].*
	from [questions] 
	inner join [tests] 
	on [tests].[id] = [questions].[test_id] 
	where [tests].[deleted_at] is null 
		and [tests].[id] = 1
		and [questions].[deleted_at] is null 
 union
	select top 3 [questions].*
	from [questions] 
	inner join [tests] 
	on [tests].[id] = [questions].[test_id] 
	where [tests].[deleted_at] is null 
		and [tests].[id] = 5
		and [questions].[deleted_at] is null 
  union
	select top 10 [questions].*
	from [questions] 
	inner join [tests] 
	on [tests].[id] = [questions].[test_id] 
	where [tests].[deleted_at] is null 
		and [tests].[id] = 7
		and [questions].[deleted_at] is null
) unioned_results
order by NEWID()
