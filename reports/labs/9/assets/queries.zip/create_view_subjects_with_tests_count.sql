create view subjects_with_tests_count
as
	select [test_subjects].*, 
	(
		select count([id]) 
		from [tests] 
		where [test_subjects].[id] = [tests].[test_subject_id] 
			and [tests].[deleted_at] is null
	) as [tests_count] 

	from [test_subjects]