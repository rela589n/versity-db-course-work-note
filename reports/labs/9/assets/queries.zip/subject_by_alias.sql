select top 1 * 
from [test_subjects] 
where [uri_alias] = 'oop'