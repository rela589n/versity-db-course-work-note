CREATE FUNCTION AllQuestionsByTestId (@paramTestId BIGINT)
returns @results TABLE(
  id         BIGINT,
  question   VARCHAR(255),
  test_id    BIGINT,
  deleted_at DATETIME)
AS
  BEGIN
      DECLARE @id INT;
      DECLARE @idTest BIGINT;
      DECLARE @idIncludeTest BIGINT;
      DECLARE @questionsQuantity INT;
      DECLARE @getid CURSOR;

      SET @getid = CURSOR
      FOR SELECT test_composite.id_test,
                 test_composite.id_include_test,
                 test_composite.questions_quantity
          FROM   [test_composite]
          WHERE  [test_composite].[id_test] = @paramTestId

      OPEN @getid

      FETCH next FROM @getid INTO @idTest, @idIncludeTest, @questionsQuantity

      WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO @results
            SELECT TOP (@questionsQuantity) [questions].*
            FROM   [questions]
                   INNER JOIN [tests]
                           ON [tests].[id] = [questions].[test_id]
            WHERE  [tests].[deleted_at] IS NULL
                   AND [tests].[id] = @idIncludeTest
                   AND [questions].[deleted_at] IS NULL

            FETCH next FROM @getid INTO @idTest, @idIncludeTest,
            @questionsQuantity
        END

      CLOSE @getid
      DEALLOCATE @getid

      RETURN
  END  